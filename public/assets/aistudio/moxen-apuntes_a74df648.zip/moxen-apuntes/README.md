# Apuntes · Moxen

Una ventana de vidrio esmerilado con semáforos que funcionan, carpetas, lista de notas y un editor donde se escribe de verdad. Cambiar el papel propaga el color con una ola circular, la chincheta cae y rebota, «Nueva nota» despliega una hoja desde su botón y las notas se arrastran a una carpeta mientras los contadores ruedan.

## Qué trae

- `index.html` — la demostración
- `apuntes.css`
- `apuntes.js`
- `LICENCIA.txt` — lo que puedes y no puedes hacer con él.

Dependencias: Ninguna.

## Cómo usarlo

1. Abre `index.html` en el navegador para verlo funcionando.
2. Copia `apuntes.css` y `apuntes.js` a tu proyecto y enlázalos como en `index.html`.
3. Copia el marcado de la demostración (lo que hay dentro de `<main>`) o
   aplícalo a tus propios elementos.

Los colores y medidas están en variables CSS al principio de los estilos, y el
código está comentado en español.

## Quick start (English)

A frosted-glass window with working traffic lights, folders, a note list and an editor you can really type in. Changing the paper spreads the colour in a circular wave, the pushpin drops and bounces, “New note” unfolds a sheet from its button and notes drag into a folder while the counters roll.

Open `index.html` to see it working, then copy the CSS and JS files into your
project and link them the way `index.html` does.

---
Moxen · moxen.cl/recursos · contacto@moxen.cl
